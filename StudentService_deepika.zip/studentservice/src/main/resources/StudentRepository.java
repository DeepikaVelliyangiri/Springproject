
public interface StudentRepository {

}
